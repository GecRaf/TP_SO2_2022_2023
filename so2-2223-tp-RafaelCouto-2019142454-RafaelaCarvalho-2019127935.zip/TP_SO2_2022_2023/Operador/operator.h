#ifndef OPERATOR_H

#include <windows.h>
#include <winbase.h>
#include <winerror.h>
#include <winreg.h>
#include <tchar.h>
#include <io.h>
#include <fcntl.h>
#include <stdio.h>
#include <conio.h>

#include "../Servidor/server.h"

#endif // !OPERATOR_H
