#pragma once

#define NOME_PIPE TEXT("\\\\.\\pipe\\TPSO2_SERVER_FROG")

#include "../Servidor/server.h"

#define FROG_SPEED 42
#define FROG_SIZE 35
